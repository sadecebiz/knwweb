<?php
error_reporting(0);
 ?>
    <ul class="sidebar navbar-nav">
      <li class="nav-item active">
        <a class="nav-link" href="index.php">
          <i class="fas fa-fw fa-tachometer-alt"></i>
          <span>Yönetim Paneli</span>
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="uyeler.php">
          <i class="fas fa-fw fa-users"></i>
          <span>Üyeler</span></a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="sunucular.php">
          <i class="fas fa-fw fa-code"></i>
          <span>Sunucular</span></a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="urunler.php">
          <i class="fas fa-fw fa-shopping-basket"></i>
          <span>Ürünler</span></a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="destekler.php">
          <i class="fas fa-fw fa-code"></i>
          <span>Destek Talepleri</span></a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="yazilar.php">
          <i class="fas fa-fw fa-code"></i>
          <span>Yazılar</span></a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="kuponlar.php">
          <i class="fas fa-fw fa-code"></i>
          <span>Kuponlar</span></a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="ayarlar.php">
          <i class="fas fa-fw fa-cogs"></i>
          <span>Ayarlar</span></a>
      </li>
    </ul>
